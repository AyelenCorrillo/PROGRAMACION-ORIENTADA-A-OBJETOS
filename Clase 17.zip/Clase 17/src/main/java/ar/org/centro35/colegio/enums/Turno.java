package ar.org.centro35.colegio.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
