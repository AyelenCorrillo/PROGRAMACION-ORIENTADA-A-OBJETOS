package ar.org.centro35.colegio.test;

import java.sql.ResultSet;

import ar.org.centro35.colegio.connectors.Connector;

public class TestConnector {
    public static void main(String[] args) {
        try (ResultSet rs=Connector.getConnection().createStatement().executeQuery("select version()")){
            if(rs.next()) {
                System.out.println(rs.getString(1));
                System.out.println("Se pudo connectar a la BD");
            }else{
                System.out.println("No se pudo conectar a la BD");
            }
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No se pudo conectar a la BD");
        }
    }
}
